package com.pkg.springjdbc.service;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.pkg.springjdbc.dao.EmployeeDao;
import com.pkg.springjdbc.pojo.Employee;

public class EmployeeDaoImpl implements EmployeeDao {

	private JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public void addData(Employee emp) {
		String query = "INSERT INTO springdb.employee (emp_id, emp_name, emp_mobile_no) VALUES (" + emp.getEmp_id()
				+ "," + "'" + emp.getEmp_name() + "'" + "," + "'" + emp.getEmp_mob_number() + "'" + ")";
		System.out.println(query);
		jdbcTemplate.execute(query);
		System.out.println("Data inserted successfully");
		System.out.println("Add data method call ");
	}

	public void fetchDataById(int emp_id) {
		// TODO Auto-generated method stub

	}

	public List<Employee> fetchAllData() {
		// TODO Auto-generated method stub
		return null;
	}

}
