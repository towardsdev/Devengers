package com.pkg.springjdbc.dao;

import java.util.List;

import com.pkg.springjdbc.pojo.Employee;

public interface EmployeeDao {
	
	public void addData(Employee employee);  // add the vlue to database.
	public void fetchDataById(int emp_id);
	public List<Employee> fetchAllData();

}
