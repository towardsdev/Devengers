package com.pkg.springjdbc.pojo;

public class Employee {

private int emp_id;
private String emp_name;
private String emp_mob_number;



public Employee(int emp_id, String emp_name, String emp_mob_number) {
	this.emp_id = emp_id;
	this.emp_name = emp_name;
	this.emp_mob_number = emp_mob_number;
}
public int getEmp_id() {
	return emp_id;
}
public void setEmp_id(int emp_id) {
	this.emp_id = emp_id;
}
public String getEmp_name() {
	return emp_name;
}
public void setEmp_name(String emp_name) {
	this.emp_name = emp_name;
}
public String getEmp_mob_number() {
	return emp_mob_number;
}
public void setEmp_mob_number(String emp_mob_number) {
	this.emp_mob_number = emp_mob_number;
}
	
}
