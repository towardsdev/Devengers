package com.pkg.springjdbc.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.pkg.springjdbc.pojo.Employee;
import com.pkg.springjdbc.service.EmployeeDaoImpl;

public class EmployeeRunner {

	public static void main(String[] args) {

		ApplicationContext context = new ClassPathXmlApplicationContext("config.xml");
		EmployeeDaoImpl emp = (EmployeeDaoImpl) context.getBean("empJDBCTemplateBean");
		emp.addData( new Employee(105,"Soutik", "9800209663"));
		((ClassPathXmlApplicationContext) context).close();

	}

}
