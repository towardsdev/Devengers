package com.springmvc;

import javax.validation.Valid;

import org.apache.tomcat.jni.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.springmvc.pojo.UserInfo;


@Controller
public class LoginController {

	@RequestMapping("/login")
	public ModelAndView login(@RequestParam("uName") String name, @RequestParam("password") String password) {
		System.out.println("Hii User");
		ModelAndView model = new ModelAndView();
		model.addObject("Username", name);
		model.addObject("Password", password);
		model.setViewName("login");
		return model;
	}


	
	@RequestMapping(value = "/logingform", method = RequestMethod.POST)
	public String loginFormController(@Valid @ModelAttribute("userInfo") UserInfo userInfo, BindingResult result) {

		if (result.hasErrors()) {
			return "welcome";
		} else {
			return "success";
		}
	}
		

	@RequestMapping(value = "/" , method = RequestMethod.GET)
	public ModelAndView welcomePage() {
		ModelAndView mv  = new ModelAndView();
		mv.addObject("userInfo", new UserInfo());
		mv.setViewName("welcome");
		return mv;
	}
	
	
}
