package com.spring.demo;

public class Vodafone implements Simcard {

	public void calling() {
		System.out.println("Calling from Voda Sim card");
	}
	

	@Override
	public void dataAccess() {
		System.out.println("Access Data from Voda providers.");
		
	}
	
}
