package com.spring.demo;

public class NewMobile {
	
	Airtel air;
	
	public void setAir(Airtel air) {
		this.air = air;
	}

	public void display() {
		System.out.println("display methos call from" + air.getLocation());
	 	
		if(air != null) {
			air.calling();
			air.dataAccess();
		} else {
			System.out.println("Object not created");
		}
		
	}

}
