package com.spring.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringRunner {

	public static void main(String[] args) {

		ApplicationContext context = new ClassPathXmlApplicationContext("beanConfig.xml");

		NewMobile sim = context.getBean("NewMobile", NewMobile.class);
		sim.display();
		
		NewMobile2 mobile = context.getBean("NewMobile2", NewMobile2.class);
		mobile.display();


	}

}
