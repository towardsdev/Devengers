package com.spring.demo;

public class NewMobile2 {
	
	Airtel air;
	
	public void setAir(Airtel air) {
		this.air = air;
	}

	public void display() {
		System.out.println("display methos call new 2");
		
		if(air != null) {
			air.calling();
			air.dataAccess();
		} else {
			System.out.println("Object not created new 2");
		}
		
	}

}
