package com.spring.demo;

public class Jio implements Simcard{
	

	public void calling() {
		System.out.println("Calling from Jio Sim card");
	}
	
	
	@Override
	public void dataAccess() {
		System.out.println("Access Data from Jio providers.");
	}
	
}
