package com.spring.demo;

public interface Simcard {

	public void calling();
	public void dataAccess();
	
}
