package com.spring.demo;

public class Airtel implements Simcard {
	

	private String location;
	/*private String name;*/
	
	/*public void setName(String name) {
		this.name = name;
	}

	
	*/
	
	/*public Airtel(String location, String name) {
		this.location = location;
		this.name = name;
	}*/
	
	
	/*public Airtel(String location) {
		this.location = location;
	}*/

	public void setLocation(String location) {
		this.location = location;
	}
	
	public String getLocation() {
		return location;
	}

	public Airtel() {
		System.out.println("airtel constractor created");
	}
	
	public void calling() {
		System.out.println("Calling from Airtel Sim card");
	}
 
	@Override
	public void dataAccess() {
		System.out.println("Access Data from Airtel providers. and access data from :-" /*+location +"and name is "+name*/);
	}

}
