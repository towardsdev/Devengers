package com.cts.spring.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

@Entity
@Table(name = "emp_address")
public class Address {

	@Column(name = "id")
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@Column(name = "city")
	private String city;

	@Column(name = "country")
	private String country;

	@Column(name = "e_id")
	private int eid;

	/*
	 * @OneToOne(fetch = FetchType.EAGER, optional = false)
	 * 
	 * @JoinColumn(name = "emp_id_fk", nullable = false)
	 */

	// @JoinTable(joinColumns = @JoinColumn(name = "customerId"), inverseJoinColumns
	// = @JoinColumn(name = "orderId"))

	/*
	 * @OneToOne
	 * 
	 * @JoinColumn(name="emp_id_fk",referencedColumnName = "emp_id" ,nullable =
	 * false)
	 */
	
	@OneToOne(fetch=FetchType.EAGER,cascade = CascadeType.ALL)
	@JoinColumn(name="emp_id_fk",nullable=false)
	private Employee employee;

	
	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public int getEid() {
		return eid;
	}

	public void setEid(int eid) {
		this.eid = eid;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

}
