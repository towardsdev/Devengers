package com.cts.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.spring.dao.EmployeeDao;
import com.cts.spring.model.Employee;

@Transactional
@Service
public class EmployeeServiceImpl implements EmployeeService {


	@Autowired
	private EmployeeDao employeeDao;

	public void addEmployee(Employee emp) {
		employeeDao.addEmployee(emp);
		
	}

	public void updateEmployee(Employee emp) {
		employeeDao.updateEmployee(emp);
		
	}

	public List<Employee> listEmployee() {
		
		return employeeDao.listEmployee();
	}

	public Employee getEmployeeById(int id) {
		return employeeDao.getEmployeeById(id);
	}

	public void removeEmployee(int id) {
		employeeDao.removeEmployee(id);
		
	}

	
}
