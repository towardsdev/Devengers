package com.cts.spring.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cts.spring.model.Technology;
import com.cts.spring.model.Employee;
import com.cts.spring.service.EmployeeService;

@Controller
@RequestMapping("/employee")
public class EmployeeController {

	@Autowired
	EmployeeService empservice;

	@RequestMapping(value = "/employeehome", method = RequestMethod.GET)
	public ModelAndView listPersons() {

		ModelAndView mv = new ModelAndView("empHome");
		mv.addObject("employee", new Employee());
		mv.addObject("listemployees", empservice.listEmployee());
		mv.addObject("technologyList", technologyList());
		return mv;

	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public String addPerson(@ModelAttribute("employee") Employee emp) {
		if (emp.getE_id() == 0) {
			// new Employee, add it
			empservice.addEmployee(emp);
		} else {
			// existing Employee, call update
			empservice.updateEmployee(emp);
		}
		return "redirect:/employee/employeehome";

	}

	@RequestMapping(value ="/edit/{id}",method = RequestMethod.GET)
	public ModelAndView editPerson(@PathVariable("id") int id) {
		ModelAndView mv= new ModelAndView("empHome");
		mv.addObject("employee", empservice.getEmployeeById(id));
		mv.addObject("listemployees", empservice.listEmployee());
		mv.addObject("technologyList", technologyList());
		return mv;
	}
	
	@RequestMapping(value = "/remove/{id}", method = RequestMethod.GET)
	public String deleteCountry(@PathVariable("id") int id) {
		empservice.removeEmployee(id);
		 return "redirect:/employee/employeehome";

	}	
	
	
	public static List<Technology> technologyList() {
		List<Technology> techList = new ArrayList<>();
		techList.add(new Technology("JAVA"));
		techList.add(new Technology("PHP"));
		techList.add(new Technology("SQL"));
		techList.add(new Technology("JQUERY"));
		techList.add(new Technology("JAVA SCRIPT"));
		return techList;
		
	}
}


