package com.cts.spring.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "employees_table")
public class Employee {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "e_id")
	private int e_id;

	@Column(name = "emp_name")
	private String emp_name;

	@Column(name = "emp_id")
	private int emp_id;

	@Column(name = "salary")
	private Long salary;

	@OneToOne(mappedBy = "employee", cascade = CascadeType.ALL)
	private Address address;

	@OneToOne(mappedBy = "emp", cascade = CascadeType.ALL)
	private EmpDept empdept;

	@OneToMany(mappedBy = "employee_tech", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private List<Technology> technology = new ArrayList<Technology>();

	public List<Technology> getTechnology() {
		return technology;
	}

	public void setTechnology(List<Technology> technology) {
		this.technology = technology;
	}

	public EmpDept getEmpdept() {
		return empdept;
	}

	public void setEmpdept(EmpDept empdept) {
		empdept.setEmp(this);
		this.empdept = empdept;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public int getE_id() {
		return e_id;
	}

	public void setE_id(int e_id) {
		this.e_id = e_id;
	}

	public String getEmp_name() {
		return emp_name;
	}

	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}

	public int getEmp_id() {
		return emp_id;
	}

	public void setEmp_id(int emp_id) {
		this.emp_id = emp_id;
	}

	public Long getSalary() {
		return salary;
	}

	public void setSalary(Long salary) {
		this.salary = salary;
	}

}
