package com.cts.spring.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Root;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cts.spring.model.Address;
import com.cts.spring.model.Technology;
import com.cts.spring.model.EmpDept;
import com.cts.spring.model.Employee;

@Repository
public class EmployeeDaoImpl implements EmployeeDao {

	@Autowired
	SessionFactory sessionFactory;

	public void addEmployee(Employee emp) {
		Session session = this.sessionFactory.getCurrentSession();
		Address add = emp.getAddress();
		EmpDept empdept = emp.getEmpdept();
		add.setEmployee(emp);
		empdept.setEmp(emp);

		for (Technology tech : emp.getTechnology()) {
			tech.setEmployee_tech(emp);
		}
		session.persist(emp);
	}

	@SuppressWarnings("unchecked")
	public void updateEmployee(Employee emp) {
		Session session = this.sessionFactory.getCurrentSession();
		Address add = emp.getAddress();
		EmpDept empdept = emp.getEmpdept();
		add.setEmployee(emp);
		empdept.setEmp(emp);
		Employee emp1 = (Employee) session.createQuery("SELECT e FROM Employee e WHERE e.e_id IN :empId")
				.setParameter("empId", emp.getE_id()).uniqueResult();
		List<Technology> tech11 = emp1.getTechnology();

		if (emp.getTechnology().size() != 0) {
			for (Technology t : tech11) {
				session.delete(t);
			}
		}
		List<Technology> tech = emp.getTechnology();
		for (Technology t : tech) {
			t.setEmployee_tech(emp);
		}

		session.merge(emp);
	}

	public List<Employee> listEmployee() {
		Session session = this.sessionFactory.getCurrentSession();
		List<Employee> empList = session.createQuery("from Employee").list();
		return empList;
	}

	public Employee getEmployeeById(int id) {
		Session session = this.sessionFactory.getCurrentSession();
		Employee emp = (Employee) session.get(Employee.class, new Integer(id));
		return emp;
	}

	public void removeEmployee(int id) {
		Session session = this.sessionFactory.getCurrentSession();
		Employee emp = (Employee) session.get(Employee.class, new Integer(id));
		if (null != emp) {
			session.remove(emp);
		}

	}

}
