package com.springmvc;

import java.util.Map;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.springmvc.pojo.Employee;

@Controller
// @RequestMapping("/emp")
public class employeeController {

	/*
	 * @RequestMapping("/empHome/{city}/{empName}") public ModelAndView
	 * EmpHome(@PathVariable Map<String, String> pathmap) {
	 * 
	 * String name = pathmap.get("empName"); ModelAndView mv = new
	 * ModelAndView("empHome"); mv.addObject("name", name);
	 * mv.addObject("city",pathmap.get("city")); return mv; }
	 */

	@RequestMapping("/empHome")
     public ModelAndView EmpHome(@PathVariable Map<String, String> pathmap) {
		ModelAndView mv = new ModelAndView("empHome");
		//mv.addObject("heading" ," Spring mvc");
		return mv;
	}

	@RequestMapping("/empLogin")
    public ModelAndView EmpLogin(@Valid @ModelAttribute("empInfo") Employee emp ,BindingResult result) {
		ModelAndView mv = new ModelAndView();
		if( result.hasErrors()) {
			mv.setViewName("empHome");
		} else {
			mv.addObject("empInfo", emp);
			mv.setViewName("empHomeDisplay");
		}
		
		//mv.addObject("heading" ," Spring mvc");
		return mv;
	}
	
	
	@ModelAttribute
	public void commonAttribute(Model model) {
		model.addAttribute("heading" ," Spring mvc");
	}
	
	
	@RequestMapping("/demo")
	public String demoDisplay() {
		System.out.println("demo page call");
		return "demo";
	}
	
	
	
	@InitBinder
	public void nameBinder( WebDataBinder binder) {
		binder.registerCustomEditor(String.class,"empName" ,new NameBinder());
	}
	
	
}
