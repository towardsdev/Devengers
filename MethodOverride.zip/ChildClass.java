
public class ChildClass extends MethodOverride{
	public  ChildClass(){
		System.out.println("Child class constructor");
	}
	public void parentDisplay(){
		System.out.println("Child Method");
	}
}
