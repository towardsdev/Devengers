package com.springmvc;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.springmvc.pojo.StudentDetails;

@RestController
@RequestMapping("/student")
public class StudentController {

	@RequestMapping(value = "/studentDetails", method =RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	 public List<StudentDetails> student () {
		 List<StudentDetails> sList = new ArrayList<>();
		// StudentDetails student =  new StudentDetails("John", "USA", 1001);
		 sList.add(new StudentDetails("John", "Usa", "1001"));
		 sList.add(new StudentDetails("Mark", "RSA", "1002", ""));
		 sList.add(new StudentDetails("Devid", "", "1003", "30"));
		 return sList;
	 }
	
	
	@RequestMapping(value = "/studentDetails/{name}", method =RequestMethod.PUT , consumes = MediaType.APPLICATION_JSON_VALUE)
	public boolean  putStudentDetails(@PathVariable("name") String name ,@RequestBody StudentDetails student) {
		System.out.println("****** Student name is :- " + name);
		System.out.println(student.getName());
		
		return true;
	}
	
}


