package com.springmvc.pojo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


@JsonPropertyOrder({"Student Name","id_no","address","age"})
@JsonInclude(JsonInclude.Include.NON_NULL)
public class StudentDetails {
	
	@JsonProperty("Student Name")
	private String name;
	@JsonIgnore
	private String address;
	private String id_no;
	private String age;

	
	public StudentDetails() {
	}
	
	
	public StudentDetails(String name, String address, String id_no, String age) {
		this.name = name;
		this.address = address;
		this.id_no = id_no;
		this.age = age;
	}
	
	
	public StudentDetails(String name, String address, String id_no) {
		this.name = name;
		this.address = address;
		this.id_no = id_no;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getId_no() {
		return id_no;
	}

	public void setId_no(String id_no) {
		this.id_no = id_no;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

}
