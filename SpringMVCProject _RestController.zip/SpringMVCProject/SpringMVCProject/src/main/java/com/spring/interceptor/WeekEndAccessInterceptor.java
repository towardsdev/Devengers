package com.spring.interceptor;

import java.util.Calendar;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

public class WeekEndAccessInterceptor extends HandlerInterceptorAdapter {

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		boolean flag = false;
		Calendar cal = Calendar.getInstance();
		int dayNumber = cal.get(cal.DAY_OF_WEEK);
		System.out.println("******" + dayNumber + "*******");

		if (dayNumber == 2) { // 2 is Monday
			response.getWriter().write(" Oppsss !!!!   . come again another day");
			flag = false;
		} else {
			flag = true;
		}
		return flag;
	}

}
