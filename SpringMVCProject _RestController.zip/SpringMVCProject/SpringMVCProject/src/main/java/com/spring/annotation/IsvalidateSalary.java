package com.spring.annotation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class IsvalidateSalary implements ConstraintValidator<Isvalidsalary, Integer>{

	@Override
	public boolean isValid(Integer value, ConstraintValidatorContext context) {
		
		if(value >1000) {
			return true;
		}
		
		return false;
	}


}
