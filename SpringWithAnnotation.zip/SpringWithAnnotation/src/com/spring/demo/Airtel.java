package com.spring.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Airtel {
	
	@Autowired
	private Vodafone voda;
	
	@Value("${airtel.custname}")
	private String custName;
	
	@Autowired
	@Qualifier("aircell")
	private Mobile mobile;
	
	

	public void displayAirtel() {
		voda.displayVoda();
		mobile.calling();
		System.out.println("Hii  "+ custName+ "  This is display method of Airtel Class");
	}

}
