package com.spring.demo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@ComponentScan(basePackages="com.spring.demo")
@PropertySource("classpath:mobile.properties")
public class MobileConfigFile {
	
	/*@Bean
	public Vodafone vodafoneBean() {
		System.out.println("vodafone bean Created");
		return new Vodafone();
	}
	
	
	@Bean
	public Mobile mobileBean() {
		
		return new Jio();
	}
	
	@Bean(name={"air" , "airtel"})
	public Airtel airtelBean() {
		Airtel air = new Airtel();
		air.setMobile(mobileBean());
		air.setVoda(vodafoneBean());
		return air;
	}

	*/
}
