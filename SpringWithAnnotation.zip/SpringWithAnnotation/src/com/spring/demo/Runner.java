package com.spring.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Runner {

	public static void main(String[] args) {

		ApplicationContext context = new AnnotationConfigApplicationContext(MobileConfigFile.class);
		Airtel airtel = context.getBean("airtel", Airtel.class);
		airtel.displayAirtel();

		((AnnotationConfigApplicationContext) context).close();

	}

}
