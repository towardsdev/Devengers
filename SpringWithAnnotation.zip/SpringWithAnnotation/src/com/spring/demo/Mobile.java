package com.spring.demo;

public interface Mobile {
	
	public void calling();

}
