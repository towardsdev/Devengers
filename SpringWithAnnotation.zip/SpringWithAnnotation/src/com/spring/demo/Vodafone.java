package com.spring.demo;

import org.springframework.stereotype.Component;

@Component
public class Vodafone {
	
	public void displayVoda() {
		System.out.println("This is vodafone Class");
	}

}
