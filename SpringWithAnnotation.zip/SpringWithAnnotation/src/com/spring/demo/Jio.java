package com.spring.demo;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
public class Jio implements Mobile {

	@Override
	public void calling() {
		System.out.println("Calling from Jio sim card");

	}

}
