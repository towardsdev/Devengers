package com.pkg.SpringJdbcTemplate.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pkg.SpringJdbcTemplate.dao.EmployeeDao;
import com.pkg.SpringJdbcTemplate.pojo.Employee;

@Service("empService")
public class EmployeeServiceImpl implements EmployeeService{

	@Autowired
	EmployeeDao employeeDao;
	
	public void addEmployee(Employee employee) {
		employeeDao.addEmployee(employee);
	}

	public void deleteEmployee(int empId) {
		// TODO Auto-generated method stub
		
	}

	public Employee find(int empId) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Employee> fetchAllEmployee() {
		employeeDao.fetchAllEmployee();
		return null;
	}

}
