package com.pkg.SpringJdbcTemplate.service;

import java.util.List;

import com.pkg.SpringJdbcTemplate.pojo.Employee;

public interface EmployeeService {

	public void addEmployee(Employee employee);

	public void deleteEmployee(int empId);

	public Employee find(int empId);

	public List<Employee> fetchAllEmployee();

}
