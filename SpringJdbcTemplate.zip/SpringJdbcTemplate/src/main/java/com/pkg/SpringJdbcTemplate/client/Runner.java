package com.pkg.SpringJdbcTemplate.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.pkg.SpringJdbcTemplate.config.ApplicationConfig;
import com.pkg.SpringJdbcTemplate.pojo.Employee;
import com.pkg.SpringJdbcTemplate.service.EmployeeService;

public class Runner {

	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(ApplicationConfig.class);
		EmployeeService service = (EmployeeService) context.getBean("empService");
		Employee emp1 = new Employee(1, "Soutik", "9988776655");
		Employee emp2 = new Employee(2, "John", "8975670987");
		Employee emp3 = new Employee(3, "Devid", "3476598067");

		/*service.addEmployee(emp1);
		service.addEmployee(emp2);
		service.addEmployee(emp3);*/
		
		service.fetchAllEmployee();
	}

}
