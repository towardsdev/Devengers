package com.pkg.SpringJdbcTemplate.dao;

import java.util.List;

import com.pkg.SpringJdbcTemplate.pojo.Employee;

public interface EmployeeDao {

	public void addEmployee(Employee employee);

	public void deleteEmployee(int empId);

	public Employee find(int empId);

	public List<Employee> fetchAllEmployee();
}
