package com.pkg.SpringJdbcTemplate.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.pkg.SpringJdbcTemplate.pojo.Employee;

@Repository
/// @Qualifier("employeeDao")
public class EmployeeDaoImpl implements EmployeeDao {

	@Autowired
	JdbcTemplate jdbcTemplate;

	public void addEmployee(Employee employee) {

		String query = "INSERT INTO springdb.employee1 ( emp_id,emp_name, emp_mobile_no) VALUES (?,?,?)";
		int i = jdbcTemplate.update(query, employee.getEmp_id(), employee.getEmp_name(), employee.getEmp_mobile_no());
		System.out.println(i);
		System.out.println("Employee dao call");
	}

	public void deleteEmployee(int empId) {
		// TODO Auto-generated method stub

	}

	public Employee find(int empId) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Employee> fetchAllEmployee() {
		String query = "SELECT * FROM springdb.employee1";
		List<Employee> employee = jdbcTemplate.query(query, new BeanPropertyRowMapper(Employee.class));
		System.out.println(employee);
		return employee;
	}

}
