package com.springmvc;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginController {
	
	
	@RequestMapping("/login")
	public ModelAndView login( @RequestParam("uName") String name, @RequestParam("password") String password) {
		System.out.println("Hii User");
		ModelAndView model = new ModelAndView();
		model.addObject("Username", name);
		model.addObject("Password", password);
		model.setViewName("login");
		 return model;
	}
	

	@RequestMapping("/logout")
	public String logOut() {
		System.out.println("Hii User");
		 return "login";
	}
	
}
